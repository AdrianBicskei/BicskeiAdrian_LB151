"""
Routes and views for the flask application.
"""

from datetime import datetime
from flask import render_template
from BicskeiAdrian_LB151 import app
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from flask import request
import random


app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@localhost/users'
app.config['SECRET_KEY'] = 'key'


db = SQLAlchemy(app)

class Spieler(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(200), nullable=False)
    zeitpunkt = db.Column(db.DateTime, default =datetime.utcnow)
    geldbetrag = db.Column(db.Integer, default=0)
    anzahlspielrunden = db.Column(db.Integer, default=1) 
    
    def __repr__(self):
        return '<Name %r>' % self.name

class Woerter(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    wort = db.Column(db.String(50), nullable=False)
    kategorie = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return '<Wort %r>' % self.wort  

@app.route('/')
@app.route('/home')
def home():      
    return render_template(
        'index.html',
        title='Home Page',
        year=datetime.now().year,
    )

@app.route('/admin_login')
def adminlogin():
    """Renders the about page."""
    return render_template(
        'admin_login.html',
        title='Login',
        year=datetime.now().year,
        message='Geben Sie Ihren Benutzernamen und Ihren Passwort ein!'
    )

@app.route('/addword')
def addword():
    """Renders the about page."""
    rows = Woerter.query.all()
    return render_template(
        'addword.html',
        title='Wort hinzufügen',
        year=datetime.now().year,
        message='Legen Sie ein Wort an!',
        rows=rows
    )

@app.route('/dropuser')
def dropuser():
    """Renders the about page."""
    rows = Spieler.query.all()
    return render_template(
        'dropuser.html',
        title='Spieler entfernen',
        year=datetime.now().year,
        message='Entfernen Sie ein Spieler durch die eingabe eines IDs!',
        rows=rows
    )


@app.route('/adminpage', methods=['POST'])
def adminpage():
    benutzername = request.form.get("benutzername")         
    passwort = request.form.get("passwort")

    # Abangen von Fehleingaben
    if not benutzername or not passwort or benutzername!="adrian" or passwort!="passwort" :         
        return render_template(
            'fail.html',
            title='Fail page',
            year=datetime.now().year,
            message='Benutzername oder Passwort falsch! Kontrolieren Sie Ihre Eingaben!'  
            )

    elif benutzername=="adrian" and passwort=="passwort":
        """Renders the adminpage."""
        rows = Woerter.query.all()
        return render_template(
            'adminpage.html',
            title='Admin Seite',
            year=datetime.now().year,
            message='Hallo Admin! Lösche Spieler mit aus der Highscore Liste oder Lege Wörter an!',
            benutzername=benutzername,
            passwort=passwort,
            rows=rows)


@app.route('/newlist', methods=['POST', 'GET'])
def newlist():
    wort = request.form.get("wort")         
    kategorie = request.form.get("kategorie")

        # Abangen von Fehleingaben
    if not wort or not kategorie  :         
        return render_template(
            'fail.html',
            title='Fail page',
            year=datetime.now().year,
            message='Kontrolieren Sie Ihre Eingaben!'  
            )
    else: 
        """Renders the adminpage."""
        wort = Woerter(wort=wort, kategorie=kategorie)
        db.session.add(wort)
        db.session.commit()
        rows = Woerter.query.all()
        return render_template(
            'newlist.html',
            title='Liste Seite',
            year=datetime.now().year,
            message='Hallo Admin! Hier die aktuelle Liste der Wörter aus dem Datenbank!',
            kategorie=kategorie,
            wort=wort,
            rows=rows)


@app.route('/newlistSpieler', methods=['POST', 'GET'])
def newlistSpieler():
    id_to_delete = request.form.get("id")         


        # Abangen von Fehleingaben
    if not id_to_delete  :         
        return render_template(
            'fail.html',
            title='Fail page',
            year=datetime.now().year,
            message='Kontrolieren Sie Ihre Eingaben!'  
            )
    else  : 
        """Renders the adminpage."""
        try:
            record_to_delete = Spieler.query.filter_by(id=id_to_delete).first()
            db.session.delete(record_to_delete)
            db.session.commit() 
        except:
            return render_template(
            'fail.html',
            title='Fail page',
            year=datetime.now().year,
            message='ID im Datenbank nicht vorhanden!'  
            )
   
        rows = Spieler.query.all()
        return render_template(
            'newlistSpieler.html',
            title='Liste Seite',
            year=datetime.now().year,
            message='Hallo Admin! Hier die aktuelle Liste der Spieler aus dem Datenbank!',
            id=id,
            rows=rows,
            record_to_delete=record_to_delete,
            id_to_delete=id_to_delete)

@app.route('/nameInput')
def nameInput():      
    return render_template(
        'nameInput.html',
        title='Glücksrad',
        year=datetime.now().year,
        message='Geben Sie Ihren Namen ein!',
    )

@app.route('/game', methods=['POST', 'GET'])
def game():
    name = request.form.get("name")         

        # Abangen von Fehleingaben
    if not name:         
        return render_template(
            'fail.html',
            title='Fail page',
            year=datetime.now().year,
            message='Geben Sie Ihren Namen ein!'  
            )
    else: 

        name = Spieler(name=name)
        db.session.add(name)
        db.session.commit()
        rows = Spieler.query.order_by(Spieler.geldbetrag.desc()).all()

        return render_template(
            'game.html',
            title='Glücksrad',
            year=datetime.now().year,
            message='Drehen Sie den Rad!',
            name=name,
            rows=rows)


@app.route('/guess')
def guess():      
    random_bool = random.randint(1, 10) != 1
    if not random_bool:
        last_spieler = Spieler.query.order_by(Spieler.id.desc()).first()
        last_spieler.geldbetrag = 0
        db.session.commit()
        rows = Spieler.query.order_by(Spieler.geldbetrag.desc()).all()
        return render_template(
            'bankrott.html',
            title='Bankrott',
            year=datetime.now().year,
            message='Sie haben das unglückliche Feld erdreht!',
            rows=rows)
    else:
        first_row = Woerter.query.first()





        question = first_row.wort
        category = first_row.kategorie


        indices = list(range(len(question)))
        indices_to_replace = random.sample(indices, 3)
        for index in indices_to_replace:
                question = question[:index] + "*" + question[index+1:]
        rows = Spieler.query.order_by(Spieler.geldbetrag.desc()).all()
    



    

   



    







    return render_template(
        'guess.html',
        title='Glücksrad',
        year=datetime.now().year,
        message='Erraten Sie das Wort!',
        question=question,
        category=category,
        rows=rows

    )





